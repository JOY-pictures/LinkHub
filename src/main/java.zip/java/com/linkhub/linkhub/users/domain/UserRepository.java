package com.linkhub.linkhub.users.domain;

import java.util.Optional;

public interface UserRepository {
    User save(User user);
    Optional<User> findById(Long id);
    Optional<User> findByUsername(String username);
    boolean existsById(Long id);
    boolean existsByUsername(String username);
}
